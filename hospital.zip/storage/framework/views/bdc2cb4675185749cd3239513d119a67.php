<?php $__env->startSection('content'); ?>
    <div id="kt_app_content" class="app-content flex-column-fluid">
        <!--begin::Content container-->
        <div id="kt_app_content_container" class="app-container container-fluid">
            <!--begin::Row-->
            <div class="row g-5 g-xl-10 mb-5 mb-xl-10">
                <!--begin::Col-->
                <div class="col-xl-12">
                    <!--begin::Table widget 14-->
                    <div class="card card-flush h-md-100">
                        <!--begin::Header-->
                        <div class="card-header pt-7">
                            <!--begin::Title-->
                            <h3 class="card-title align-items-start flex-column">
                                <span class="card-label fw-bold text-gray-800">All Drugs</span>
                                <span class="text-gray-400 mt-1 fw-semibold fs-6">Updated
                                    <?php echo e(Carbon\Carbon::parse(App\Models\Drug::latest()->pluck('updated_at')->first())->diffForHumans()); ?></span>
                            </h3>
                            <!--end::Title-->
                            <!--begin::Toolbar-->
                            <div class="card-toolbar">
                            </div>
                            <!--end::Toolbar-->
                        </div>
                        <!--end::Header-->
                        <!--begin::Body-->
                        <div class="card-body pt-6">
                            <!--begin::Table container-->
                            <?php $__sessionArgs = ['success'];
if (session()->has($__sessionArgs[0])) :
if (isset($value)) { $__sessionPrevious[] = $value; }
$value = session()->get($__sessionArgs[0]); ?>
                                <div class="container text-start badge-light-success w-100 rounded py-5 my-14">
                                    <h3>
                                        <span>
                                            <i class="icon fas fa-check text-success"></i>
                                        </span>
                                        <span><?php echo e($value); ?></span>
                                    </h3>
                                </div>
                            <?php unset($value);
if (isset($__sessionPrevious) && !empty($__sessionPrevious)) { $value = array_pop($__sessionPrevious); }
if (isset($__sessionPrevious) && empty($__sessionPrevious)) { unset($__sessionPrevious); }
endif;
unset($__sessionArgs); ?>
                            <?php $__sessionArgs = ['error'];
if (session()->has($__sessionArgs[0])) :
if (isset($value)) { $__sessionPrevious[] = $value; }
$value = session()->get($__sessionArgs[0]); ?>
                                <div class="container badge-light-danger w-100 rounded py-5 my-14">
                                    <h3><?php echo e($value); ?></h3>
                                </div>
                            <?php unset($value);
if (isset($__sessionPrevious) && !empty($__sessionPrevious)) { $value = array_pop($__sessionPrevious); }
if (isset($__sessionPrevious) && empty($__sessionPrevious)) { unset($__sessionPrevious); }
endif;
unset($__sessionArgs); ?>
                            <div class="table-responsive">
                                <!--begin::Table-->
                                <table class="table table-row-dashed align-middle gs-0 gy-3 my-0">
                                    <!--begin::Table head-->
                                    <thead>
                                        <tr class="fs-7 fw-bold text-gray-400 border-bottom-0">
                                            <th class="p-0 pb-3 text-start">#</th>
                                            <th class="p-0 pb-3 text-center">Name</th>
                                            <th class="p-0 pb-3 text-center">Dosage</th>
                                            <th class="p-0 pb-3 text-center pe-12">Production Date</th>
                                            <th class="p-0 pb-3 text-center pe-7">Expiry Date</th>
                                            <th class="p-0 pb-3 text-center"></th>
                                        </tr>
                                    </thead>
                                    <!--end::Table head-->
                                    <!--begin::Table body-->
                                    <tbody>
                                        <?php $__currentLoopData = $drugs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $drug): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td>
                                                    <div class="d-flex align-items-center">
                                                        <div class="d-flex justify-content-start flex-column">
                                                            <span
                                                                class="text-gray-800 fw-bold text-hover-primary mb-1 fs-6"><?php echo e($loop->index + 1); ?></span>
                                                        </div>
                                                    </div>
                                                </td>
                                                <td class="text-center">
                                                    <span class="text-gray-600 fw-bold fs-6"><?php echo e($drug->name); ?></span>
                                                </td>
                                                <td class="text-center">
                                                    <!--begin::Label-->
                                                    <span
                                                        class="badge badge-light-success fs-base"><?php echo e($drug->dosage . 'cm'); ?></span>
                                                    <!--end::Label-->
                                                </td>
                                                <td class="text-center">
                                                    <span><?php echo e($drug->productionDate); ?></span>
                                                </td>
                                                <td class="text-center">
                                                    <?php echo e($drug->expiryDate); ?>

                                                </td>
                                                <td class="text-center d-flex">
                                                    <a href="<?php echo e(route('drugs.edit', $drug->id)); ?>"
                                                        class="btn btn-bg-secondary mx-3">
                                                        <!--begin::Svg Icon | path: icons/duotune/arrows/arr001.svg-->
                                                        Edit
                                                        </span>
                                                        <!--end::Svg Icon-->
                                                    </a>
                                                    <form action="<?php echo e(route('drugs.destroy', $drug->id)); ?>" method="POST">
                                                        <?php echo csrf_field(); ?>
                                                        <?php echo method_field('DELETE'); ?>
                                                        <button class="btn btn-danger">Delete</button>
                                                    </form>
                                                </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                    <!--end::Table body-->
                                </table>
                            </div>
                            <!--end::Table-->
                        </div>
                        <span class="p-3"><?php echo e($drugs->links()); ?></span>
                        <!--end: Card Body-->
                    </div>
                    <!--end::Table widget 14-->
                </div>
                <!--end::Col-->
            </div>
            <!--end::Row-->
        </div>
        <!--end::Content container-->
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('title', 'Index Drugs'); ?>

<?php echo $__env->make('welcome', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\MSI\Desktop\Programming\Laravel\Wadie\hospital\hospital\resources\views/drugs/index.blade.php ENDPATH**/ ?>