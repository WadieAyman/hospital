<?php $__env->startSection('content'); ?>
    <div id="kt_app_content" class="app-content flex-column-fluid">
        <!--begin::Content container-->
        <div id="kt_app_content_container" class="app-container container-fluid">
            <!--begin::Row-->
            <div class="row g-5 g-xl-8 mt-7">
                <div>
                    <?php $__sessionArgs = ['success'];
if (session()->has($__sessionArgs[0])) :
if (isset($value)) { $__sessionPrevious[] = $value; }
$value = session()->get($__sessionArgs[0]); ?>
                        <div class="container text-start badge-light-success w-100 rounded py-5 my-14">
                            <h3>
                                <span>
                                    <i class="icon fas fa-check text-success"></i>
                                </span>
                                <span><?php echo e($value); ?></span>
                            </h3>
                        </div>
                    <?php unset($value);
if (isset($__sessionPrevious) && !empty($__sessionPrevious)) { $value = array_pop($__sessionPrevious); }
if (isset($__sessionPrevious) && empty($__sessionPrevious)) { unset($__sessionPrevious); }
endif;
unset($__sessionArgs); ?>
                    <?php $__sessionArgs = ['error'];
if (session()->has($__sessionArgs[0])) :
if (isset($value)) { $__sessionPrevious[] = $value; }
$value = session()->get($__sessionArgs[0]); ?>
                        <div class="container badge-light-danger w-100 rounded py-5 my-14">
                            <h3><?php echo e($value); ?></h3>
                        </div>
                    <?php unset($value);
if (isset($__sessionPrevious) && !empty($__sessionPrevious)) { $value = array_pop($__sessionPrevious); }
if (isset($__sessionPrevious) && empty($__sessionPrevious)) { unset($__sessionPrevious); }
endif;
unset($__sessionArgs); ?>
                    <!--begin::List Widget 2-->
                    <div class="card card-xl-stretch mb-xl-8">
                        <!--begin::Header-->
                        <div class="card-header border-0">
                            <h3 class="card-title fw-bold text-dark">Assigned Drugs for: <?php echo e($patient->name); ?></h3>
                            <div class="card-toolbar"></div>
                        </div>
                        <!--end::Header-->
                        <!--begin::Body-->
                        <div class="card-body pt-2">
                            <!--begin::Item-->
                            <div class="d-flex align-items-center mb-7">
                                <!--begin::Text-->
                                <div class="flex-grow-1">
                                    <ul>
                                        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <span
                                                class="d-block w-250px text-center text-light badge badge-primary my-3"
                                                style="font-size: 22px">
                                                <li class="nav-link d-flex p-3" style="justify-content: space-between;">
                                                    <span class="mt-1"><?php echo e($item->name); ?></span>
                                                    <?php if(auth()->guard('doctor')->check()): ?>
                                                        <span>
                                                            <form action="<?php echo e(route('unsigne_drug', [$item->id,$patient->id])); ?>" method="POST">
                                                                <?php echo csrf_field(); ?>
                                                                <?php echo method_field('DELETE'); ?>
                                                                <button type="submit" class="btn btn-icon btn-sm bg-primary">
                                                                    <i class="icon fas fa-times text-danger mb-2" style="font-size: 22px;"></i>
                                                                </button>
                                                            </form>
                                                        </span>
                                                    <?php endif; ?>
                                                </li>
                                            </span>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </ul>
                                </div>
                                <!--end::Text-->
                            </div>
                            <!--end::Item-->
                        </div>
                        <!--end::Body-->
                    </div>
                    <!--end::List Widget 2-->
                </div>
            </div>
            <!--end::Row-->
        </div>
        <!--end::Content container-->
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('title', 'Show patients assigned drugs'); ?>

<?php echo $__env->make('welcome', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\MSI\Desktop\Programming\Laravel\Wadie\hospital\hospital\resources\views/patients/show.blade.php ENDPATH**/ ?>