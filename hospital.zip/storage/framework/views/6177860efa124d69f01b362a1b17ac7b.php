<?php $__env->startSection('content'); ?>
    <center>
        <!--begin::Body-->
        <div class="d-flex flex-column flex-lg-row-fluid w-50 p-10 order-2 order-lg-1">
            <!--begin::Form-->
            <div class="d-flex flex-center flex-column flex-lg-row-fluid">
                <!--begin::Wrapper-->
                <div class="container-fluid card p-5">
                    <!--begin::Form-->
                    <form class="form" action="<?php echo e(route('drugs.update',$drug->id)); ?>" method="POST" novalidate="novalidate">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PUT'); ?>
                        <!--begin::Heading-->
                        <div class="text-center mb-11">
                            <!--begin::Title-->
                            <h1 class="text-dark fw-bolder mb-3">Edit <span class="text-muted"><?php echo e($drug->name); ?></span> Drug
                            </h1>
                            <!--end::Title-->
                        </div>
                        <!--begin::Heading-->
                        <!--begin::Separator-->
                        <?php $__sessionArgs = ['success'];
if (session()->has($__sessionArgs[0])) :
if (isset($value)) { $__sessionPrevious[] = $value; }
$value = session()->get($__sessionArgs[0]); ?>
                            <div class="container text-start badge-light-success w-100 rounded py-5 my-14">
                                <h3>
                                    <span>
                                        <i class="icon fas fa-check text-success"></i>
                                    </span>
                                    <span><?php echo e($value); ?></span>
                                </h3>
                            </div>
                        <?php unset($value);
if (isset($__sessionPrevious) && !empty($__sessionPrevious)) { $value = array_pop($__sessionPrevious); }
if (isset($__sessionPrevious) && empty($__sessionPrevious)) { unset($__sessionPrevious); }
endif;
unset($__sessionArgs); ?>
                        <?php $__sessionArgs = ['error'];
if (session()->has($__sessionArgs[0])) :
if (isset($value)) { $__sessionPrevious[] = $value; }
$value = session()->get($__sessionArgs[0]); ?>
                            <div class="container badge-light-danger w-100 rounded py-5 my-14">
                                <h3><?php echo e($value); ?></h3>
                            </div>
                        <?php unset($value);
if (isset($__sessionPrevious) && !empty($__sessionPrevious)) { $value = array_pop($__sessionPrevious); }
if (isset($__sessionPrevious) && empty($__sessionPrevious)) { unset($__sessionPrevious); }
endif;
unset($__sessionArgs); ?>
                        <!--end::Separator-->
                        <!--begin::Input group=-->
                        <div class="fv-row mb-8">
                            <!--begin::Name-->
                            <input type="text" placeholder="Name" name="name" value="<?php echo e($drug->name); ?>"
                                id="name" autocomplete="off" class="form-control bg-transparent" />
                            <!--end::Name-->
                        </div>
                        <!--end::Input group=-->
                        <!--begin::Input group=-->
                        <div class="fv-row mb-8">
                            <!--begin::Dosage-->
                            <input type="number" placeholder="Dosage" value="<?php echo e($drug->dosage); ?>" name="dosage"
                                id="dosage" class="form-control bg-transparent" />
                            <!--end::Dosage-->
                        </div>
                        <!--end::Input group=-->
                        <!--begin::Input group=-->
                        <div class="fv-row mb-8">
                            <!--begin::Production Date-->
                            <input type="date" placeholder="Production Date" value="<?php echo e($drug->productionDate); ?>"
                                name="productionDate" id="productionDate" autocomplete="off"
                                class="form-control bg-transparent" />
                            <!--end::Production Date-->
                        </div>
                        <!--end::Input group=-->
                        <!--begin::Input group=-->
                        <div class="fv-row mb-8">
                            <!--begin::Expiry Date-->
                            <input type="date" placeholder="expiryDate" value="<?php echo e($drug->expiryDate); ?>" name="expiryDate"
                                id="expiryDate" autocomplete="off" class="form-control bg-transparent" />
                            <!--end::Expiry Date-->
                        </div>
                        <!--end::Input group=-->
                        <!--begin::Submit button-->
                        <div class="d-grid mb-10">
                            <button type="submit" class="btn btn-primary">
                                <!--begin::Indicator label-->
                                <span class="indicator-label">Save Changes</span>
                                <!--end::Indicator label-->
                            </button>
                        </div>
                        <!--end::Submit button-->
                    </form>
                    <!--end::Form-->
                </div>
                <!--end::Wrapper-->
            </div>
            <!--end::Form-->
        </div>
        <!--end::Body-->
    </center>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('title', 'Edit new Drug'); ?>

<?php echo $__env->make('welcome', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\MSI\Desktop\Programming\Laravel\Wadie\hospital\hospital\resources\views/drugs/edit.blade.php ENDPATH**/ ?>