<?php $__env->startSection('content'); ?>
    <center>
        <!--begin::Body-->
        <div class="d-flex flex-column flex-lg-row-fluid w-50 p-10 order-2 order-lg-1">
            <!--begin::Form-->
            <div class="d-flex flex-center flex-column flex-lg-row-fluid">
                <!--begin::Wrapper-->
                <div class="container-fluid card p-5">
                    <!--begin::Form-->
                    <form class="form" action="<?php echo e(route('patients.update', $patient->id)); ?>" method="POST"
                        novalidate="novalidate">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PUT'); ?>
                        <!--begin::Heading-->
                        <div class="text-center mb-11">
                            <!--begin::Title-->
                            <h1 class="text-dark fw-bolder mb-3">Edit Patient Details</h1>
                            <!--end::Title-->
                        </div>
                        <!--begin::Heading-->
                        <!--begin::Separator-->
                        <?php $__sessionArgs = ['success'];
if (session()->has($__sessionArgs[0])) :
if (isset($value)) { $__sessionPrevious[] = $value; }
$value = session()->get($__sessionArgs[0]); ?>
                            <div class="container text-start badge-light-success w-100 rounded py-5 my-14">
                                <h3>
                                    <span>
                                        <i class="icon fas fa-check text-success"></i>
                                    </span>
                                    <span><?php echo e($value); ?></span>
                                </h3>
                            </div>
                        <?php unset($value);
if (isset($__sessionPrevious) && !empty($__sessionPrevious)) { $value = array_pop($__sessionPrevious); }
if (isset($__sessionPrevious) && empty($__sessionPrevious)) { unset($__sessionPrevious); }
endif;
unset($__sessionArgs); ?>
                        <?php $__sessionArgs = ['error'];
if (session()->has($__sessionArgs[0])) :
if (isset($value)) { $__sessionPrevious[] = $value; }
$value = session()->get($__sessionArgs[0]); ?>
                            <div class="container badge-light-danger w-100 rounded py-5 my-14">
                                <h3><?php echo e($value); ?></h3>
                            </div>
                        <?php unset($value);
if (isset($__sessionPrevious) && !empty($__sessionPrevious)) { $value = array_pop($__sessionPrevious); }
if (isset($__sessionPrevious) && empty($__sessionPrevious)) { unset($__sessionPrevious); }
endif;
unset($__sessionArgs); ?>
                        <!--end::Separator-->
                        <!--begin::Input group=-->
                        <div class="fv-row mb-8">
                            <!--begin::name-->
                            <input type="text" placeholder="name" name="name" value="<?php echo e($patient->name); ?>"
                                id="name" autocomplete="off" class="form-control bg-transparent" />
                            <!--end::name-->
                        </div>
                        <!--end::Input group=-->
                        <!--begin::Input group=-->
                        <div class="fv-row mb-8">
                            <!--begin::phoneNumber-->
                            <input type="tel" placeholder="phoneNumber" name="phoneNumber"
                                value="<?php echo e($patient->phoneNumber); ?>" id="name" autocomplete="off"
                                class="form-control bg-transparent" maxlength="15" />
                            <!--end::phoneNumber-->
                        </div>
                        <!--end::Input group=-->
                        <!--begin::Input group=-->
                        <div class="fv-row mb-8">
                            <!--begin::age-->
                            <input type="number" placeholder="age" name="age" value="<?php echo e($patient->age); ?>"
                                id="name" autocomplete="off" class="form-control bg-transparent" />
                            <!--end::age-->
                        </div>
                        <!--end::Input group=-->
                        <!--begin::Input group=-->
                        <div class="fv-row mb-8">
                            <!--begin::gender-->
                            <select name="gender" class="form-control bg-transparent">
                                <option selected disabled>--Select patient gender--</option>
                                <option value="Male">Male</option>
                                <option value="Female">Female</option>
                            </select>
                            <!--end::gender-->
                        </div>
                        <!--end::Input group=-->
                        <!--begin::Input group=-->
                        <div class="fv-row mb-8">
                            <!--begin::problemtion Date-->
                            <textarea placeholder="problem" name="problem" class="form-control bg-transparent" rows="5" cols="12"><?php echo e($patient->problem); ?></textarea>
                            <!--end::Production problem-->
                        </div>
                        <!--end::Input group=-->
                        <!--begin::Submit button-->
                        <div class="d-grid mb-10">
                            <button type="submit" class="btn btn-primary">
                                <!--begin::Indicator label-->
                                <span>Save Changes</span>
                                <!--end::Indicator label-->
                            </button>
                        </div>
                        <!--end::Submit button-->
                    </form>
                    <!--end::Form-->
                </div>
                <!--end::Wrapper-->
            </div>
            <!--end::Form-->
        </div>
        <!--end::Body-->
    </center>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('title', 'Edit patient'); ?>

<?php echo $__env->make('welcome', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\MSI\Desktop\Programming\Laravel\Wadie\hospital\hospital\resources\views/patients/edit.blade.php ENDPATH**/ ?>